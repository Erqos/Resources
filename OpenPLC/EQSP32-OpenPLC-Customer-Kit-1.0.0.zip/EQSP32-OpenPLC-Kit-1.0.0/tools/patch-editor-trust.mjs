// Patch the installed OpenPLC Editor for the EQSP32 (steps 0 to 2c below):
//
// 1. TRUST: add the local dev signing key (keys/eqsp32-dev.pub.pem) to the
//    editor's trusted VPP package keys. The editor (Autonomy-Logic v4.x)
//    bakes its trusted Ed25519 keys into dist/main/main.js inside
//    resources/app.asar and refuses to install (and removes at startup) any
//    package not signed by one of them.
//
// 2. SLOT-0 DISPLAY: renumber the module-slot labels in the renderer from
//    1-based to 0-based. The EQSP32 main unit is a fixed module in the first
//    slot, so with 0-based labels the UI shows the main unit as "Slot 0" and
//    the EQX expansion modules as "Slot 1".."Slot 15" — matching the physical
//    module addresses on the EQX bus. Purely cosmetic: internal slot numbers
//    (vpp_config.h, io-mapping store) are untouched.
//
// The script backs up app.asar -> app.asar.bak on first run, extracts the
// asar, applies whichever patches are missing, repacks (native *.node modules
// stay unpacked) and replaces app.asar.
//
// 0. SHORT ARDUINO PATH (not in app.asar): the esp32 2.0.17 compiler (gcc
//    8.4) reaches its own headers through bin/../lib/gcc/.../../../../ and
//    is limited to 260-character paths. Under the editor's default data
//    folder (%APPDATA%\open-plc-editor\arduino\data) that path reaches 260
//    characters for any Windows user name of 5 or more characters, and every
//    EQSP32 build stops with "bits/c++config.h: No such file or directory".
//    The editor creates User\arduino-cli.yaml once and then keeps the
//    directories it finds there, so this step points directories.data and
//    directories.user at C:\EQSP32-OpenPLC. Cores and libraries downloaded
//    before are not moved; the editor downloads them again on the next build.
//
// The OpenPLC Editor must be CLOSED while this runs.
//
// Usage: node tools/patch-editor-trust.mjs

import { execFileSync } from 'node:child_process'
import { copyFileSync, cpSync, existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { basename, dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

// --- 0. Short Arduino data path ------------------------------------------------
const SHORT_ARDUINO_DIR = 'C:\\EQSP32-OpenPLC'
const cliYamlPath = join(process.env.APPDATA, 'open-plc-editor', 'User', 'arduino-cli.yaml')
const yamlQuote = (p) => `'${p.replaceAll("'", "''")}'`
if (!existsSync(cliYamlPath)) {
  console.warn(
    `Arduino path: ${cliYamlPath} does not exist yet. Start the OpenPLC Editor once, ` +
      'close it, and run this script again so builds use a short path.',
  )
} else {
  const yaml = readFileSync(cliYamlPath, 'utf-8')
  const want = { data: join(SHORT_ARDUINO_DIR, 'data'), user: join(SHORT_ARDUINO_DIR, 'user') }
  let out = yaml
  let missing = false
  for (const [key, dir] of Object.entries(want)) {
    // A top-level-indented key inside the directories: block, e.g. "  data: 'C:\...'"
    const re = new RegExp(`^(directories:\\r?\\n(?:[ \\t]+.*\\r?\\n)*?)([ \\t]+${key}:)[^\\r\\n]*`, 'm')
    if (!re.test(out)) {
      missing = true
      continue
    }
    out = out.replace(re, (_m, head, label) => `${head}${label} ${yamlQuote(dir)}`)
  }
  if (missing) {
    console.warn('Arduino path: directories.data/user not found in arduino-cli.yaml; left unchanged.')
  } else if (out === yaml) {
    console.log(`Arduino path: already ${SHORT_ARDUINO_DIR}.`)
  } else {
    mkdirSync(want.data, { recursive: true })
    mkdirSync(want.user, { recursive: true })
    copyFileSync(cliYamlPath, `${cliYamlPath}.bak`)
    writeFileSync(cliYamlPath, out)
    console.log(`Arduino path: cores and libraries now go to ${SHORT_ARDUINO_DIR} (old file kept as arduino-cli.yaml.bak).`)
  }
}

const root = dirname(dirname(fileURLToPath(import.meta.url)))
const KEY_ID = 'eqsp32-dev'
const pubPem = readFileSync(join(root, 'keys', `${KEY_ID}.pub.pem`), 'utf-8')

const resourcesDir = join(
  process.env.LOCALAPPDATA,
  'Programs',
  'open-plc-editor',
  'resources',
)
const asarPath = join(resourcesDir, 'app.asar')
const backupPath = join(resourcesDir, 'app.asar.bak')

if (!existsSync(asarPath)) {
  console.error(`app.asar not found at ${asarPath}`)
  process.exit(1)
}

// --- 1. Backup ---------------------------------------------------------------
if (!existsSync(backupPath)) {
  copyFileSync(asarPath, backupPath)
  console.log(`Backed up app.asar -> ${backupPath}`)
}

// --- 2. Extract + patch --------------------------------------------------------
const workDir = mkdtempSync(join(tmpdir(), 'openplc-asar-'))
const extractDir = join(workDir, 'app')
const npxCmd = process.platform === 'win32' ? 'npx.cmd' : 'npx'
const asarCli = (args) => execFileSync(npxCmd, ['--yes', '@electron/asar', ...args], { stdio: 'inherit', shell: true })

asarCli(['extract', `"${asarPath}"`, `"${extractDir}"`])

let changed = false

// --- 2a. Trust key (main process) ---------------------------------------------
// The trusted keys are an inline object literal:
//   {"openplc-2026":"-----BEGIN PUBLIC KEY-----\n...\n-----END PUBLIC KEY-----\n"}
// Up to 4.1.x it sits in dist/main/main.js; from 4.3.x the main process is
// code-split and it sits in a numbered chunk (4.3.2: dist/main/359.js), so
// search every .js file of dist/main and require exactly one match.
const trustRe = /\{"openplc-2026":"-----BEGIN PUBLIC KEY-----\\n[^"]*"\}/
const mainDir = join(extractDir, 'dist', 'main')
const mainFiles = readdirSync(mainDir)
  .filter((n) => n.endsWith('.js'))
  .map((n) => join(mainDir, n))
  .filter((p) => statSync(p).isFile())

if (mainFiles.some((p) => readFileSync(p, 'utf-8').includes(`"${KEY_ID}":"-----BEGIN PUBLIC KEY-----`))) {
  console.log('Trust: dev key already present.')
} else {
  const hits = mainFiles.filter((p) => trustRe.test(readFileSync(p, 'utf-8')))
  if (hits.length !== 1) {
    console.error(
      hits.length === 0
        ? 'Could not locate the trusted-keys object in dist/main — editor version may have changed.'
        : `Trusted-keys object found in ${hits.length} files in dist/main — refusing to guess.`,
    )
    process.exit(1)
  }
  const pemJs = pubPem.replace(/\r/g, '').replace(/\n/g, '\\n')
  const trustJs = readFileSync(hits[0], 'utf-8').replace(trustRe, (m) => `${m.slice(0, -1)},"${KEY_ID}":"${pemJs}"}`)
  writeFileSync(hits[0], trustJs)
  console.log(`Trust: inserted key "${KEY_ID}" into dist/main/${basename(hits[0])}`)
  changed = true
}

// --- 2b. Slot-0 display (renderer.js) --------------------------------------------
// Cosmetic renumbering of module-slot labels: internal slot N (1-based) is
// displayed as N-1 so the fixed EQSP32 main-unit module reads "Slot 0" and
// EQX modules read "Slot 1".."Slot 15" (their physical bus addresses).
// ORDER MATTERS: the first replacement must run before the second one
// recreates its search string.
const rendererJsPath = join(extractDir, 'dist', 'renderer', 'renderer.js')
let rendererJs = readFileSync(rendererJsPath, 'utf-8')

if (rendererJs.includes('children:["Slot ",e-1]')) {
  console.log('Slot-0 display: already patched.')
} else {
  const slotPatches = [
    // I/O Mapping table per-slot group header (e = internal slot, 1-based)
    ['children:["Slot ",e]', 'children:["Slot ",e-1]'],
    // Module slot list item (e = array index, 0-based)
    ['children:["Slot ",e+1]', 'children:["Slot ",e]'],
    // Slot detail panel heading (b = array index, 0-based)
    ['children:["Slot ",b+1]', 'children:["Slot ",b]'],
    // Module search placeholder "(slot N)"
    ['slotNumber:b+1', 'slotNumber:b'],
    // Variable picker dropdown group label (r.slot = internal, 1-based)
    ['`Slot ${r.slot}: ${r.moduleName}`', '`Slot ${r.slot-1}: ${r.moduleName}`'],
    // Address registry consumer label (e = internal slot, 1-based)
    ['label:`Slot ${e}`', 'label:`Slot ${e-1}`'],
    // Address conflict message (t[1] = internal slot as string)
    ['`VPP slot ${t[1]} channel ${t[2]}`', '`VPP slot ${Number(t[1])-1} channel ${t[2]}`'],
  ]
  let applied = 0
  for (const [from, to] of slotPatches) {
    const idx = rendererJs.indexOf(from)
    if (idx === -1) {
      console.warn(`Slot-0 display: pattern not found (cosmetic, skipped): ${from}`)
      continue
    }
    if (rendererJs.indexOf(from, idx + 1) !== -1) {
      console.warn(`Slot-0 display: pattern not unique, skipped: ${from}`)
      continue
    }
    rendererJs = rendererJs.slice(0, idx) + to + rendererJs.slice(idx + from.length)
    applied++
  }
  if (applied > 0) {
    writeFileSync(rendererJsPath, rendererJs)
    console.log(`Slot-0 display: applied ${applied}/${slotPatches.length} label patches to renderer.js`)
    changed = true
  } else {
    console.warn('Slot-0 display: no patterns matched — editor version may have changed. Slot labels stay 1-based.')
  }
}

// --- 2c. Default aliases (renderer.js) -------------------------------------------
// The module system fills the alias column only from user input. Auto-fill a
// default alias for untouched channels so every channel is usable from the
// variable Location dropdown immediately:
//   - fixed main-unit module: faceplate name with an underscore ("ADIO3" -> "ADIO_3")
//   - expansion modules: family code + per-family index + channel label
//     ("eqxio" #1 "X1.DIO3" -> "XIO_1_DIO3")
// The separator is "_": editor 4.3.x treats "." in an alias as illegal and
// renames such aliases when a project opens. Earlier versions of this patch
// used "." and are upgraded in place.
// User-entered aliases always take precedence (stored aliases win).
// In the minified source: e = slot array index, t = moduleId, n = module
// definition, i = channel, u = slots array, a = stored-alias map, and the
// key variable is o up to 4.1.x and s in 4.3.x. The module-system site is the
// one followed by modeFieldId (4.3.x has a second, unrelated alias site).
const aliasTo = (k, sep = '_') =>
  `alias:a.get(${k})??(n.fixed` +
  `?i.name.replace(/^([A-Za-z]+)(\\d+)$/,"$1${sep}$2")` +
  `:t.replace(/\\d+$/,"").toUpperCase().replace(/^EQ/,"")+"${sep}"` +
  `+u.slice(0,e+1).filter((q)=>q&&q.replace(/\\d+$/,"")===t.replace(/\\d+$/,"")).length+"${sep}"` +
  '+i.name.replace(/^X\\d+\\./,"")),'
const aliasSites = [
  { from: 'alias:a.get(s)??"",modeFieldId', key: 's', tail: 'modeFieldId' },
  { from: 'alias:a.get(o)??"",', key: 'o', tail: '' },
]
const oldDotKey = ['s', 'o'].find((k) => rendererJs.includes(aliasTo(k, '.')))

if (['s', 'o'].some((k) => rendererJs.includes(aliasTo(k)))) {
  console.log('Default aliases: already patched.')
} else if (oldDotKey) {
  rendererJs = rendererJs.replace(aliasTo(oldDotKey, '.'), aliasTo(oldDotKey))
  writeFileSync(rendererJsPath, rendererJs)
  console.log('Default aliases: upgraded from "." to "_" separators in renderer.js')
  changed = true
} else if (/alias:a\.get\([os]\)\?\?\(n\.fixed/.test(rendererJs)) {
  console.warn('Default aliases: an unknown earlier auto-fill patch is present; left unchanged.')
} else {
  const site = aliasSites.find(({ from }) => {
    const idx = rendererJs.indexOf(from)
    return idx !== -1 && rendererJs.indexOf(from, idx + 1) === -1
  })
  if (!site) {
    console.warn('Default aliases: pattern not found or not unique — skipped (aliases stay empty until typed).')
  } else {
    const idx = rendererJs.indexOf(site.from)
    rendererJs = rendererJs.slice(0, idx) + aliasTo(site.key) + site.tail + rendererJs.slice(idx + site.from.length)
    writeFileSync(rendererJsPath, rendererJs)
    console.log('Default aliases: auto-fill patch applied to renderer.js')
    changed = true
  }
}

if (!changed) {
  console.log('Nothing to patch.')
  rmSync(workDir, { recursive: true, force: true })
  process.exit(0)
}

// --- 3. Repack + install -------------------------------------------------------
const outAsar = join(workDir, 'out.asar')
asarCli(['pack', `"${extractDir}"`, `"${outAsar}"`, '--unpack', '"*.node"'])

copyFileSync(outAsar, asarPath)
const outUnpacked = `${outAsar}.unpacked`
if (existsSync(outUnpacked)) {
  try {
    cpSync(outUnpacked, `${asarPath}.unpacked`, { recursive: true, force: true })
  } catch (err) {
    // A running editor keeps its loaded .node files locked. The unpacked
    // files never change across our repacks (same serialport prebuilds), so
    // a locked destination is fine as long as the files are already there.
    console.warn(`Warning: could not refresh app.asar.unpacked (${err.code}); existing files kept.`)
  }
}
rmSync(workDir, { recursive: true, force: true })
console.log('Patched app.asar installed. Restart the OpenPLC Editor.')
