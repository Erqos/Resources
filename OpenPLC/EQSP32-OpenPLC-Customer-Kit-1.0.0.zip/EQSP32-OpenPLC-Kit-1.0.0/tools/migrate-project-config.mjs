// Normalize an OpenPLC project's saved EQSP32 configuration after a package
// upgrade. Old package versions stored different Mode strings and module ids;
// the editor silently DROPS any channel whose saved mode is not a key of the
// current catalog (this is what makes pins like ADIO1 disappear from the I/O
// Mapping table). This tool rewrites the project data instead of polluting
// the shipped Mode dropdowns with legacy labels.
//
// What it does (with .bak backups, per file):
//   devices/configuration.json
//     - maps legacy mode strings to the current code-first labels where the
//       target module supports them, otherwise deletes the value so the
//       catalog default applies again
//     - maps retired module ids in the slot list (eqxpt24 / eqxpt3 -> eqxpt)
//     - removes obsolete v0.1-0.5 stores (eq_adio_*, eq_io, eq_eqx)
//   devices/pin-mapping.json
//     - clears the EQSP32CE entry list (Pin Mapping is disabled for this
//       board; stale rows only produce load warnings)
//
// Usage: node tools/migrate-project-config.mjs <project folder>
// Close the project in the OpenPLC Editor first, or the editor may write the
// old data back on top.

import { copyFileSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const BOARD = "EQSP32CE";

// Legacy label -> current label.
const LEGACY_MODES = {
  "Digital Input": "DIN (Digital Input)",
  "Switch Input (debounced)": "SWT (Switch Input)",
  "Switch Input": "SWT (Switch Input)",
  "Analog Voltage Input": "AIN (Analog Voltage Input)",
  "0-5V Analog Input": "AIN (Analog Voltage Input)",
  "Current Loop 4-20 mA": "CIN (Current Loop 4-20mA)",
  "Current Loop 4-20mA": "CIN (Current Loop 4-20mA)",
  "NTC Temperature": "TIN (NTC Temperature)",
  "Relative Analog Input": "RAIN (Relative Analog Input)",
  "Pulse Counter": "PCC (Pulse Counter)",
  "Digital Output": "POUT (Digital Output)",
  "Power PWM Output": "POUT (Power PWM Output)",
  "Relay Derated Output": "RELAY (Relay Derated Output)",
  "Power Output": "POUT (Power Output)",
  // 0.7.2 -> 0.7.3: SAOUT label now carries the pair-sync warning inline.
  "SAOUT (Synchronized Analog Output)": "SAOUT (Synced Output - set BOTH AO1 and AO2 to SAOUT)",
};

// Retired catalog ids.
const LEGACY_SLOT_IDS = { eqxpt24: "eqxpt", eqxpt3: "eqxpt" };

// Currently valid mode labels per module id (must match gen-module-system.mjs).
const VALID_MODES = {
  eqsp32: [
    "DIN (Digital Input)",
    "SWT (Switch Input)",
    "AIN (Analog Voltage Input)",
    "CIN (Current Loop 4-20mA)",
    "TIN (NTC Temperature)",
    "RAIN (Relative Analog Input)",
    "PCC (Pulse Counter)",
    "POUT (Digital Output)",
    "POUT (Power PWM Output)",
    "RELAY (Relay Derated Output)",
  ],
  eqxio: ["DIN (Digital Input)", "SWT (Switch Input)", "POUT (Power Output)"],
  eqxai: ["AIN (Analog Voltage Input)", "CIN (Current Loop 4-20mA)", "TIN (NTC Temperature)"],
  eqxra: [
    "RELAY (Relay Output)",
    "AOUT (Analog Voltage Output)",
    "SAOUT (Synced Output - set BOTH AO1 and AO2 to SAOUT)",
  ],
  eqxpt: ["PT100 (2/4-wire)", "PT100 (3-wire)"],
  eqxtc: ["TC (Thermocouple)"],
  eqxph: ["PH (pH Input)"],
};

const projectDir = process.argv[2];
if (!projectDir) {
  console.error("Usage: node tools/migrate-project-config.mjs <project folder>");
  process.exit(1);
}

let changes = 0;
const log = (msg) => {
  changes++;
  console.log("  - " + msg);
};

function migrateModuleConfiguration(mc) {
  if (!mc || typeof mc !== "object") return;
  const slots = Array.isArray(mc.slots) ? mc.slots : [];
  for (let i = 0; i < slots.length; i++) {
    const mapped = LEGACY_SLOT_IDS[slots[i]];
    if (mapped) {
      log(`slot ${i + 1}: module id ${slots[i]} -> ${mapped}`);
      slots[i] = mapped;
    }
  }
  const cfg = mc.slotsConfig;
  if (!cfg || typeof cfg !== "object") return;
  for (const [slotKey, fields] of Object.entries(cfg)) {
    if (!fields || typeof fields !== "object") continue;
    // Internal slot 1 is always the fixed main unit; other slots hold the
    // module id recorded in the slot list (index slot-1).
    const slotNum = Number(slotKey);
    const moduleId = slotNum === 1 ? "eqsp32" : slots[slotNum - 1];
    const valid = VALID_MODES[moduleId] ?? [];
    for (const [fieldId, value] of Object.entries(fields)) {
      if (!/^(ch\d+|ao\d+|rl\d+)_mode$/.test(fieldId) || typeof value !== "string") continue;
      if (valid.includes(value)) continue;
      const mapped = LEGACY_MODES[value];
      if (mapped && valid.includes(mapped)) {
        log(`slot ${slotKey} ${fieldId}: "${value}" -> "${mapped}"`);
        fields[fieldId] = mapped;
      } else {
        log(`slot ${slotKey} ${fieldId}: dropped stale value "${value}" (default applies)`);
        delete fields[fieldId];
      }
    }
  }
}

function migrateStore(store) {
  if (!store || typeof store !== "object") return;
  for (const key of Object.keys(store)) {
    if (/^eq_adio_\d+$/.test(key) || key === "eq_eqx" || key === "eq_io") {
      log(`removed obsolete store "${key}"`);
      delete store[key];
    }
  }
  migrateModuleConfiguration(store["module-configuration"]);
}

// --- configuration.json ---
const cfgPath = join(projectDir, "devices", "configuration.json");
if (existsSync(cfgPath)) {
  console.log(`Migrating ${cfgPath}`);
  const cfg = JSON.parse(readFileSync(cfgPath, "utf-8"));
  migrateStore(cfg.vendorScreenData);
  if (cfg.vendorScreenDataByBoard && typeof cfg.vendorScreenDataByBoard === "object")
    for (const board of Object.keys(cfg.vendorScreenDataByBoard))
      migrateStore(cfg.vendorScreenDataByBoard[board]);
  copyFileSync(cfgPath, cfgPath + ".bak");
  writeFileSync(cfgPath, JSON.stringify(cfg, null, 2) + "\n");
} else {
  console.log(`No devices/configuration.json under ${projectDir}`);
}

// --- pin-mapping.json ---
const pmPath = join(projectDir, "devices", "pin-mapping.json");
if (existsSync(pmPath)) {
  try {
    const pm = JSON.parse(readFileSync(pmPath, "utf-8"));
    if (pm && typeof pm === "object" && !Array.isArray(pm) && Array.isArray(pm[BOARD]) && pm[BOARD].length > 0) {
      log(`cleared ${pm[BOARD].length} stale Pin Mapping row(s) for ${BOARD}`);
      pm[BOARD] = [];
      copyFileSync(pmPath, pmPath + ".bak");
      writeFileSync(pmPath, JSON.stringify(pm, null, 2) + "\n");
    }
  } catch {
    console.log(`Skipped unreadable ${pmPath}`);
  }
}

console.log(changes > 0 ? `Done: ${changes} change(s). Backups written next to the originals.` : "Nothing to migrate.");
