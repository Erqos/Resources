# License

Copyright (c) 2026 Erqos Technologies

The EQSP32 OpenPLC package has two parts with different licenses.

| Part | Files | License |
|---|---|---|
| OpenPLC package files | Everything except the EQSP32 library: the HAL source, the editor screens, the manifest, the board images, the tools, the documents, the examples, and `lib/EQSP32/src/ETH.h` | MIT License (Part A) |
| EQSP32 library | `lib/EQSP32`: the precompiled EQSP32 library and its headers, except `ETH.h` | Erqos Binary License (Part B) |

SPDX license expression: `MIT AND LicenseRef-Erqos-EQSP32-Binary`

---

## Part A: MIT License

Copyright (c) 2026 Erqos Technologies

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

## Part B: Erqos Binary License for the EQSP32 library

Copyright (c) 2026 Erqos Technologies. All rights reserved, except as granted
below.

1. **Grant.** You may use, copy and redistribute the EQSP32 library in binary
   form, free of charge, on the conditions below. You may copy and use the
   supplied header files to compile applications that use the library.
2. **Building firmware.** You may compile your applications with the library,
   link it statically, and distribute the resulting firmware, for example
   inside your products.
3. **Your applications.** You keep all rights in your own applications and may
   distribute them on the terms you choose.
4. **Erqos products only.** You may use the library only to run software on
   Erqos products (EQSP32 controllers and EQX expansion modules).
5. **Unmodified library package.** When you redistribute the library itself
   (the `lib/EQSP32` folder, outside a firmware image), redistribute it
   unmodified and complete, as Erqos released it, with this license.
6. **No reverse engineering.** You may not modify, reverse engineer, decompile
   or disassemble the library, except where applicable law expressly allows it
   despite this restriction.
7. **Ownership.** Erqos Technologies keeps all rights in the library. This
   license gives you no right to its source code.
8. **No warranty.** THE LIBRARY IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
   KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO
   EVENT SHALL ERQOS TECHNOLOGIES BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   OUT OF OR IN CONNECTION WITH THE LIBRARY OR THE USE OR OTHER DEALINGS IN THE
   LIBRARY.
9. **End of the license.** If you break these terms, your rights under this
   Part B end.
