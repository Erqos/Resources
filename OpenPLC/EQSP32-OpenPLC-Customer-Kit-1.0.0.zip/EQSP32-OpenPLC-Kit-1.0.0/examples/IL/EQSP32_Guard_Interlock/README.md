# EQSP32 Guard Interlock (IL example)

A machine motor that runs only while its guard is closed, in Instruction List
(IL), with a warning lamp when someone switches on with the guard open.

> **Safety:** this is an example of PLC logic. An emergency stop, guard
> locking and other safety functions need safety-rated devices and wiring.
> Do not build them from a standard PLC program.

## Open it

1. Copy the `EQSP32_Guard_Interlock` folder somewhere outside the kit.
2. In OpenPLC Editor: **Open**, then select the copied folder.
3. Device → Configuration: pick the EQSP32's COM port.
4. **Build**, then **Upload**.

## Wiring (EQSP32CE)

| Terminal | Alias | Mode | Connect |
|---|---|---|---|
| ADIO1 | `Run_Switch` | DIN | Run switch (closed = run) |
| ADIO2 | `Guard_Switch` | DIN | Guard switch (closed = guard closed) |
| ADIO3 | `Stop_Button` | DIN | Stop push button (closed = pressed) |
| DIO15 | `Machine_Motor` | POUT | Motor contactor or relay |
| DIO16 | `Guard_Lamp` | POUT | Warning lamp |

## What it does

```text
LD   Run          (* run switch on        *)
AND  Guard        (* and guard closed     *)
ANDN Stop         (* and stop not pressed *)
ST   Motor

LD   Run          (* run switch on        *)
ANDN Guard        (* but guard open       *)
ST   Warning
```

## What you should see

- In the editor's debugger: `Motor` is TRUE only while `Run` and `Guard` are
  TRUE and `Stop` is FALSE. `Warning` is TRUE while `Run` is TRUE and `Guard`
  is FALSE.
- In EQMonitor: the terminals carry the names above.

## Change it for your machine

- Rename a terminal in Device → System Layout → Slot 0 (Alias column), and
  keep the program's `AT <alias>` the same as the new name.
