# EQSP32 Start/Stop (Ladder example)

A pump started and stopped with two push buttons, in Ladder Diagram (LD):
the classic start/stop circuit with a set coil, a reset coil and a run lamp.

## Open it

1. Copy the `EQSP32_Start_Stop` folder somewhere outside the kit.
2. In OpenPLC Editor: **Open**, then select the copied folder.
3. Device → Configuration: pick the EQSP32's COM port.
4. **Build**, then **Upload**.

## Wiring (EQSP32CE)

| Terminal | Alias | Mode | Connect |
|---|---|---|---|
| ADIO1 | `Start_Button` | DIN | Start push button (closed = pressed) |
| ADIO2 | `Stop_Button` | DIN | Stop push button (closed = pressed) |
| DIO15 | `Pump_Motor` | POUT | Pump contactor or relay |
| DIO16 | `Run_Lamp` | POUT | Run lamp |

## What it does

- **Rung 1:** `Start` sets the `Motor` coil (S). The motor stays on after the
  button is released.
- **Rung 2:** `Stop` resets the `Motor` coil (R). This rung comes after rung 1,
  so Stop wins when both buttons are pressed.
- **Rung 3:** the `Lamp` coil follows the motor.
- After a restart of the EQSP32 the pump stays off until Start is pressed.

## What you should see

- In the editor's debugger: `Motor` and `Lamp` turn TRUE when you press Start,
  and FALSE when you press Stop.
- In EQMonitor: the terminals carry the names above (for example
  `Start_Button` on terminal 1).

## Change it for your machine

- Rename a terminal in Device → System Layout → Slot 0 (Alias column), and
  give the variable the new name as its location in the variable table.
- A stop button with a normally closed contact also stops the pump when its
  wire breaks: wire it NC and make the rung 2 contact a negated contact.
