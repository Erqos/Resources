# EQSP32 Fan Timer (FBD example)

A cooling fan switched by a thermostat, in Function Block Diagram (FBD): an
on-delay timer ignores short contact chatter, and an off-delay timer keeps the
fan running for a while after the thermostat opens.

## Open it

1. Copy the `EQSP32_Fan_Timer` folder somewhere outside the kit.
2. In OpenPLC Editor: **Open**, then select the copied folder.
3. Device → Configuration: pick the EQSP32's COM port.
4. **Build**, then **Upload**.

## Wiring (EQSP32CE)

| Terminal | Alias | Mode | Connect |
|---|---|---|---|
| ADIO1 | `Thermostat` | DIN | Thermostat contact (closed = too warm) |
| DIO15 | `Cooling_Fan` | POUT | Fan contactor or relay |

## What it does

`Thermostat_On` → **TON** (PT 3 s) → **TOF** (PT 10 s) → `Fan`

- The fan starts when the thermostat has been closed for 3 s without a break.
- The fan keeps running for 10 s after the thermostat opens.

## What you should see

- In the editor's debugger: close the thermostat, and `Fan` turns TRUE about
  3 s later. Open it, and `Fan` turns FALSE about 10 s later.
- In EQMonitor: the terminals carry the names above.

## Change it for your machine

- The delays are the `PT` inputs of the two timer blocks (`T#3s`, `T#10s`).
- Rename a terminal in Device → System Layout → Slot 0 (Alias column), and
  give the variable the new name as its location in the variable table.
