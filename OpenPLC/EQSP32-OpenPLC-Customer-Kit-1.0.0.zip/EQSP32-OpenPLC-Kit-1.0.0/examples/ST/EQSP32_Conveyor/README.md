# EQSP32 Conveyor (example project)

A small conveyor: start and stop push buttons, a motor and a run lamp, an
encoder that measures the belt position from a home switch, and a part counter.
It shows the EQSP32 features of package 1.0.0: named I/O (aliases that also
appear in EQMonitor), the quadrature encoder (QENC) and the pulse total (PCC).

## Open it

1. Copy the `EQSP32_Conveyor` folder somewhere outside the kit.
2. In OpenPLC Editor: **Open**, then select the copied folder.
3. Device → Configuration: pick the EQSP32's COM port.
4. **Build**, then **Upload**.

## Wiring (EQSP32CE)

| Terminal | Alias | Mode | Connect |
|---|---|---|---|
| ADIO1 | `Start_Button` | DIN | Start push button (closed = pressed) |
| ADIO2 | `Stop_Button` | DIN | Stop push button (closed = pressed) |
| ADIO3 | `Home_Switch` | DIN | Sensor at the home position |
| DIO9 | `Conveyor_Encoder` | QENC A (Quad encoder signal A) | Encoder signal A |
| DIO10 | `Conveyor_Forward` | QENC B (Quad encoder signal B) | Encoder signal B |
| DIO11 | `Part_Sensor` | PCC (Pulse Total) | Part sensor, one pulse per part |
| DIO15 | `Conveyor_Motor` | POUT | Motor contactor or relay |
| DIO16 | `Run_Lamp` | POUT | Run lamp |

Power the EQSP32 through **VIn** when an encoder is connected.

## What it does

- **Start** switches the motor and the lamp on; they stay on until **Stop**.
  Stop wins when both are pressed.
- **Position** is the encoder count since the home switch last closed. The
  encoder counter itself is never reset: the program stores the count at the
  home switch and subtracts it (`Position := Encoder - Home_Pos`).
- **Parts** counts parts since the last start, the same way.
- **Position** and **Parts** are copied to `%MD0` and `%MD1` every scan, so an
  HMI or a Modbus master can read them (an encoder position or a pulse total
  at `%ID` is not in the Modbus map). Add a Modbus server first (Servers →
  Modbus server; user manual §10): Position is holding registers 52-53, Parts
  54-55, high word first.

## What you should see

- In the editor's debugger: `Running`, `Position` and `Parts` change as you
  press the buttons, turn the encoder and pulse the part sensor.
- In EQMonitor: the terminals carry the names above (for example
  `Start_Button` on terminal 1).

## Change it for your machine

- Rename a terminal in Device → System Layout → Slot 0 (Alias column); keep the
  program's `AT <alias>` the same as the new name.
- Encoder resolution or direction: Slot 0 → Configuration (A/B x4, x2, x1,
  pulse + direction, up/down; Reversed).
- Count falling edges or both edges on the part sensor: Slot 0 →
  Configuration → Pulse Edge.
